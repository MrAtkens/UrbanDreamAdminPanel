export const URLAdmin = 'https://urban.gibkii-kamen.kz'
export const URLVendor = 'https://vendor.bazarjok.xyz'
